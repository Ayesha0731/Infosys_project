import { useEffect, useState } from "react";
import axios from "axios";
import "./RegisterEmployee.css";
import { toast } from 'react-toastify';

const BASE_URL = "http://localhost:8080";

const CATEGORY_TYPES = ["Technical", "Administrative", "SERVICE"];

function RegisterEmployee() {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [dob, setDob] = useState("");
  const [categoryType, setCategoryType] = useState("Technical");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const token = localStorage.getItem("jwtToken");

  useEffect(() => {
    fetchAllUsers();
  }, []);

  //  Fetch all users
  const fetchAllUsers = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${BASE_URL}/auth/all-user`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setUsers(res.data);
    } catch (err) {
      console.error("Failed to fetch users", err);
    } finally {
      setLoading(false);
    }
  };

  //  Add employee
  const addEmployee = async () => {
    if (!dob.trim()) {
      alert("Please enter Date of Birth");
      return;
    }

    setSubmitting(true);
    try {
      await axios.post(
        `${BASE_URL}/api/employee/add-employee/${selectedUser.id}`,
        {
          Dob: dob,
          categoryType: categoryType,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      toast.success("✅ Employee added successfully");
      setSelectedUser(null);
      setDob("");
      setCategoryType("Technical");
      fetchAllUsers();
    } catch (err) {
      console.error("Failed to add employee", err);
      toast.error("❌ Failed to add employee");
    } finally {
      setSubmitting(false);
    }
  };

  const getUserRoleIcon = (role) => {
    switch(role) {
      case 'EMPLOYEE': return '👨‍💼';
      case 'USER': return '👤';
      case 'ADMIN': return '👑';
      default: return '👤';
    }
  };

  const getCategoryIcon = (category) => {
    switch(category) {
      case 'Technical': return '🔧';
      case 'Administrative': return '📋';
      case 'SERVICE': return '🛠️';
      default: return '📄';
    }
  };

  return (
  <div className="emp-register-employee-container">
  {/* Header Section */}
  <div className="emp-register-header">
    <div className="emp-header-content">
      <h1 className="emp-main-title">👨‍💼 Register Employees</h1>
      <p className="emp-subtitle">Convert regular users to employees by assigning roles and categories</p>
    </div>
    <div className="emp-header-stats">
      <div className="emp-stat-card">
        <div className="emp-stat-icon">👥</div>
        <div className="emp-stat-info">
          <span className="emp-stat-value">{users.length}</span>
          <span className="emp-stat-label">Total Users</span>
        </div>
      </div>
      <div className="emp-stat-card">
        <div className="emp-stat-icon">👨‍💼</div>
        <div className="emp-stat-info">
          <span className="emp-stat-value">
            {users.filter(u => u.roles === "EMPLOYEE").length}
          </span>
          <span className="emp-stat-label">Employees</span>
        </div>
      </div>
    </div>
  </div>

  
  <div className="emp-refresh-section">
    <button 
      className="emp-refresh-btn"
      onClick={fetchAllUsers}
      disabled={loading}
    >
      {loading ? (
        <>
          <span className="emp-spinner"></span>
          Refreshing...
        </>
      ) : (
        <>
          <span className="emp-btn-icon">🔄</span>
          Refresh Users List
        </>
      )}
    </button>
  </div>

  {/* Users List */}
  {loading ? (
    <div className="emp-loading-container">
      <div className="emp-spinner-large"></div>
      <p>Loading users...</p>
    </div>
  ) : (
    <div className="emp-users-grid">
      {users.length === 0 ? (
        <div className="emp-empty-state">
          <div className="emp-empty-icon">📭</div>
          <h3>No Users Found</h3>
          <p>No users are registered in the system.</p>
        </div>
      ) : (
        users.map((user) => (
          <div className="emp-user-card" key={user.id}>
            <div className="emp-card-header">
              <div className="emp-user-id">
                <span className="emp-id-label">ID</span>
                <span className="emp-id-number">#{user.id}</span>
              </div>
              <div className="emp-role-badge">
                <span className="emp-role-icon">
                  {getUserRoleIcon(user.roles)}
                </span>
                <span className="emp-role-text">
                  {user.roles === "EMPLOYEE" ? "Employee" : "User"}
                </span>
              </div>
            </div>

            <div className="emp-user-info">
              <div className="emp-info-row">
                <span className="emp-info-label">👤 Username</span>
                <span className="emp-info-value">{user.username}</span>
              </div>
              <div className="emp-info-row">
                <span className="emp-info-label">📧 Email</span>
                <span className="emp-info-value">{user.email || "Not provided"}</span>
              </div>
              {user.roles === "EMPLOYEE" && (
                <div className="emp-employee-tag">
                  <span className="emp-tag-icon">✅</span>
                  <span>Already Registered as Employee</span>
                </div>
              )}
            </div>

            <div className="emp-card-footer">
              {user.roles !== "EMPLOYEE" ? (
                <button
                  className="emp-set-employee-btn"
                  onClick={() => setSelectedUser(user)}
                >
                  <span className="emp-btn-icon">👨‍💼</span>
                  Register as Employee
                </button>
              ) : (
                <div className="emp-already-employee">
                  <span className="emp-status-icon">✅</span>
                  <span>Already an Employee</span>
                </div>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  )}

 
  {selectedUser && (
    <div className="emp-employee-modal-overlay">
      <div className="emp-employee-modal">
        <div className="emp-modal-header">
          <div className="emp-modal-user-info">
            <div className="emp-user-avatar">
              {getUserRoleIcon('EMPLOYEE')}
            </div>
            <div>
              <h2>Register as Employee</h2>
              <p className="emp-user-details">
                User: <strong>{selectedUser.username}</strong> 
                (ID: #{selectedUser.id})
              </p>
            </div>
          </div>
          <button 
            className="emp-close-btn"
            onClick={() => setSelectedUser(null)}
            disabled={submitting}
          >
            ✕
          </button>
        </div>

        <div className="emp-modal-content">
          <div className="emp-form-section">
            <div className="emp-form-group">
              <label className="emp-form-label">
                <span className="emp-label-icon">📅</span>
                Date of Birth
              </label>
              <div className="emp-input-hint">
                Enter date in format: "12 June 2025"
              </div>
              <input
                type="text"
                className="emp-form-input"
                placeholder="Example: 12 June 2025"
                value={dob}
                onChange={(e) => setDob(e.target.value)}
                disabled={submitting}
              />
            </div>

            <div className="emp-form-group">
              <label className="emp-form-label">
                <span className="emp-label-icon">📂</span>
                Category Type
              </label>
              <div className="emp-category-selector">
                {CATEGORY_TYPES.map((category) => (
                  <button
                    key={category}
                    type="button"
                    className={`emp-category-option ${categoryType === category ? 'selected' : ''}`}
                    onClick={() => setCategoryType(category)}
                    disabled={submitting}
                  >
                    <span className="emp-category-icon">
                      {getCategoryIcon(category)}
                    </span>
                    {category}
                  </button>
                ))}
              </div>
            </div>

            <div className="emp-info-note">
              <div className="emp-note-icon">ℹ️</div>
              <div className="emp-note-content">
                <strong>Note:</strong> Once registered as an employee, 
                the user will gain access to employee-specific features 
                and will be assigned to the selected category.
              </div>
            </div>
          </div>
        </div>

        <div className="emp-modal-actions">
          <button
            className="emp-cancel-btn"
            onClick={() => setSelectedUser(null)}
            disabled={submitting}
          >
            <span className="emp-btn-icon">✖️</span>
            Cancel
          </button>
          <button
            className="emp-submit-btn"
            onClick={addEmployee}
            disabled={!dob.trim() || submitting}
          >
            {submitting ? (
              <>
                <span className="emp-spinner"></span>
                Registering...
              </>
            ) : (
              <>
                <span className="emp-btn-icon">✅</span>
                Register as Employee
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )}
</div>
  );
}

export default RegisterEmployee;