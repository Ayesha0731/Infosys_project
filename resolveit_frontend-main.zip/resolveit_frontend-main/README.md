## ResolveIt Frontend
### Installation
```
Git clone https://github.com/shubham9345/resolveit_frontend.git
```
```
npm install
```
### Core Dependencies
```
npm install react-router-dom
```
```
npm install axios
```
```
npm install react-toastify
```
```
npm install react-icons
```
```
npm install jwt-decode
```
### Run Application
```
npm run dev
```
