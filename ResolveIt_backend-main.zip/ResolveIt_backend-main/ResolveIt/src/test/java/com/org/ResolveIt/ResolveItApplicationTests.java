package com.org.ResolveIt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResolveItApplicationTests {

	@Test
	void contextLoads() {
	}

}
