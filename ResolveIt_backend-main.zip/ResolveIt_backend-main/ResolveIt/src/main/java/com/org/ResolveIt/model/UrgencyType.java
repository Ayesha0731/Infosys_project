package com.org.ResolveIt.model;

public enum UrgencyType {
    HIGH, MEDIUM, LOW, MILD
}
