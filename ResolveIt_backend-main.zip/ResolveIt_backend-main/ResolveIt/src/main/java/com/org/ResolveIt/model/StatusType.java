package com.org.ResolveIt.model;

public enum StatusType {
    Open, InProgress, Resolved ,PENDING,Escalated
}
