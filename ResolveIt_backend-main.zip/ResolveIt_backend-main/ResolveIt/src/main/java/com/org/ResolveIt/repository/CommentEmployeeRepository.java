package com.org.ResolveIt.repository;

import com.org.ResolveIt.model.CommentEmployee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentEmployeeRepository extends JpaRepository<CommentEmployee,Long> {
}
