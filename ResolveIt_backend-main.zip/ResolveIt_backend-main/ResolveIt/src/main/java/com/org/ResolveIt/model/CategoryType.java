package com.org.ResolveIt.model;

public enum CategoryType {
    Technical, Administrative, SERVICE
}
