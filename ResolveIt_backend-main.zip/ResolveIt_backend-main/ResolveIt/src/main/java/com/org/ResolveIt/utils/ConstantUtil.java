package com.org.ResolveIt.utils;

public class ConstantUtil {
    public static final long TOKEN_EXPIRATION_TIME = 1000 * 60 * 60;
    public static final String INVALID_CREDENTIAL = "please fill the correct username and password";
}
