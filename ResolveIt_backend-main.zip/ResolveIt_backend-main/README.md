# ResolveIt
## Installation Steps
```
Git clone https://github.com/shubham9345/ResolveIt_backend.git
```
## Database Config
- spring.datasource.username= your database username
- spring.datasource.password= your database password

## Run
- Go to ***ResolveItApplication.java*** and start run button and The application will start successfully on: http://localhost:8080
